import ollama

# Step 1: Collect info about item through user
itemInfo = {
    "name": input("Item name: "),
    "description": input("Description: "),
    "asking_price": input("Asking price: "),
    "platform": input("Listed on (e.g., Facebook Marketplace): ")
}

# Step 2: Initialize chat history
message_history = [
    {
        'role': 'system',
        'content': """
You are an expert Facebook Marketplace negotiator helping a buyer message a seller.

Always keep messages:
- Friendly and casual
- Short and text-message-like
- Focused on expressing interest, gently negotiating a better price (15–30% lower), and optionally asking a clarifying question.
"""
    }
]

# Step 3: Create first user prompt
user_prompt = f"""
Here's the item:
- Title: {itemInfo['name']}
- Description: {itemInfo['description']}
- Asking Price: {itemInfo['asking_price']}
- Platform: {itemInfo['platform']}

Write a first message to the seller based on the guidelines.
"""

message_history.append({'role': 'user', 'content': user_prompt})

# Step 4: Query Ollama and update history
response = ollama.chat(
    model='phi3:mini',
    messages=message_history,
    stream=False,
    options={'temperature': 0.5}
)

assistant_msg = response['message']['content']
message_history.append({'role': 'assistant', 'content': assistant_msg})

print("\n💬 Suggested Message:")
print(assistant_msg)

# Step 5: Optional follow-up
while True:
    follow_up = input("\nYou (optional reply to seller or type 'exit'): ")
    if follow_up.lower() in ['exit', 'quit']:
        break

    message_history.append({'role': 'user', 'content': follow_up})

    response = ollama.chat(
        model='phi3:mini',
        messages=message_history,
        stream=False,
        options={'temperature': 0.5}
    )

    assistant_msg = response['message']['content']
    message_history.append({'role': 'assistant', 'content': assistant_msg})

    print("\n🤖 Bot Response:")
    print(assistant_msg)
